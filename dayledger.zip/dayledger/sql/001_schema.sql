-- Day Ledger schema. Postgres 14+.
-- All timestamps stored UTC (timestamptz). work_date is the IST calendar day.

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'employee' CHECK (role IN ('employee','admin')),
  password_hash TEXT NOT NULL,
  slack_user_id TEXT,
  active        BOOLEAN NOT NULL DEFAULT TRUE,
  must_reset    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tasks (
  id           SERIAL PRIMARY KEY,
  title        TEXT NOT NULL,
  note         TEXT DEFAULT '',
  assignee_id  INT NOT NULL REFERENCES users(id),
  created_by   INT NOT NULL REFERENCES users(id),
  due_at       TIMESTAMPTZ NOT NULL,
  status       TEXT NOT NULL DEFAULT 'not_started'
               CHECK (status IN ('not_started','in_progress','blocked','completed','rolled')),
  completed_at TIMESTAMPTZ,
  archived     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tasks_assignee_open ON tasks (assignee_id, status) WHERE archived = FALSE;
CREATE INDEX IF NOT EXISTS tasks_due ON tasks (due_at) WHERE archived = FALSE;

-- One row per person per working day. This is attendance.
CREATE TABLE IF NOT EXISTS work_days (
  id            SERIAL PRIMARY KEY,
  user_id       INT NOT NULL REFERENCES users(id),
  work_date     DATE NOT NULL,
  clock_in_at   TIMESTAMPTZ NOT NULL,
  clock_out_at  TIMESTAMPTZ,
  close_reason  TEXT CHECK (close_reason IN ('user','catchup','idle_timeout','admin')),
  closed_by     INT REFERENCES users(id),
  admin_note    TEXT,
  UNIQUE (user_id, work_date)
);
CREATE INDEX IF NOT EXISTS work_days_open ON work_days (user_id) WHERE clock_out_at IS NULL;

-- Hours logged against a task, as part of closing a day.
CREATE TABLE IF NOT EXISTS time_entries (
  id          SERIAL PRIMARY KEY,
  work_day_id INT NOT NULL REFERENCES work_days(id) ON DELETE CASCADE,
  task_id     INT NOT NULL REFERENCES tasks(id),
  hours       NUMERIC(5,2) NOT NULL CHECK (hours >= 0 AND hours <= 16),
  status_set  TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (work_day_id, task_id)
);

-- Audit: every status change, including who and when.
CREATE TABLE IF NOT EXISTS task_events (
  id          SERIAL PRIMARY KEY,
  task_id     INT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  actor_id    INT NOT NULL REFERENCES users(id),
  from_status TEXT,
  to_status   TEXT NOT NULL,
  at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Throttle for the recurring due-date notification.
CREATE TABLE IF NOT EXISTS reminder_log (
  id       SERIAL PRIMARY KEY,
  user_id  INT NOT NULL REFERENCES users(id),
  sent_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  channel  TEXT NOT NULL,
  task_ids INT[] NOT NULL
);
CREATE INDEX IF NOT EXISTS reminder_log_recent ON reminder_log (user_id, sent_at DESC);
