import { q } from './db.js';

const esc = (v) => {
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/**
 * One row per person for the month: attendance, hours logged, clock time,
 * and task completion. Hours logged and clock time will differ — that gap is
 * the useful signal, so both are reported rather than reconciled.
 */
export async function monthlyCsv(month) {
  const start = `${month}-01`;
  const { rows } = await q(
    `WITH bounds AS (
       SELECT $1::date AS s, ($1::date + INTERVAL '1 month')::date AS e
     ),
     days AS (
       SELECT w.user_id,
              COUNT(*) FILTER (WHERE w.clock_out_at IS NOT NULL) AS days_closed,
              COUNT(*) AS days_present,
              COUNT(*) FILTER (WHERE w.close_reason IN ('idle_timeout','admin')) AS days_auto_closed,
              ROUND(SUM(EXTRACT(EPOCH FROM (w.clock_out_at - w.clock_in_at)))::numeric / 3600, 2) AS clock_hours
       FROM work_days w, bounds b
       WHERE w.work_date >= b.s AND w.work_date < b.e
       GROUP BY w.user_id
     ),
     logged AS (
       SELECT w.user_id, ROUND(SUM(te.hours), 2) AS logged_hours
       FROM time_entries te
       JOIN work_days w ON w.id = te.work_day_id, bounds b
       WHERE w.work_date >= b.s AND w.work_date < b.e
       GROUP BY w.user_id
     ),
     done AS (
       SELECT t.assignee_id AS user_id,
              COUNT(*) FILTER (WHERE t.completed_at IS NOT NULL) AS tasks_completed,
              COUNT(*) FILTER (WHERE t.completed_at IS NOT NULL AND t.completed_at <= t.due_at) AS completed_on_time
       FROM tasks t, bounds b
       WHERE t.completed_at >= b.s AND t.completed_at < b.e
       GROUP BY t.assignee_id
     ),
     still_open AS (
       SELECT assignee_id AS user_id,
              COUNT(*) AS open_tasks,
              COUNT(*) FILTER (WHERE due_at < now()) AS overdue_tasks
       FROM tasks WHERE archived = FALSE AND status <> 'completed'
       GROUP BY assignee_id
     )
     SELECT u.name, u.email,
            COALESCE(d.days_present, 0)    AS days_present,
            COALESCE(d.days_closed, 0)     AS days_closed,
            COALESCE(d.days_auto_closed,0) AS days_auto_closed,
            COALESCE(d.clock_hours, 0)     AS clock_hours,
            COALESCE(l.logged_hours, 0)    AS logged_hours,
            COALESCE(c.tasks_completed, 0) AS tasks_completed,
            COALESCE(c.completed_on_time,0) AS completed_on_time,
            COALESCE(o.open_tasks, 0)      AS open_tasks,
            COALESCE(o.overdue_tasks, 0)   AS overdue_tasks
     FROM users u
     LEFT JOIN days d ON d.user_id = u.id
     LEFT JOIN logged l ON l.user_id = u.id
     LEFT JOIN done c ON c.user_id = u.id
     LEFT JOIN still_open o ON o.user_id = u.id
     WHERE u.active = TRUE
     ORDER BY u.name`,
    [start]
  );

  const header = [
    'Name', 'Email', 'Days present', 'Days closed properly', 'Days auto-closed',
    'Clock hours', 'Logged hours', 'Tasks completed', 'Completed on time',
    'Open tasks', 'Overdue tasks'
  ];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push([
      r.name, r.email, r.days_present, r.days_closed, r.days_auto_closed,
      r.clock_hours, r.logged_hours, r.tasks_completed, r.completed_on_time,
      r.open_tasks, r.overdue_tasks
    ].map(esc).join(','));
  }
  return lines.join('\n') + '\n';
}
