import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from './db.js';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'sql');

const files = (await fs.readdir(dir)).filter(f => f.endsWith('.sql')).sort();
for (const f of files) {
  const sql = await fs.readFile(path.join(dir, f), 'utf8');
  await pool.query(sql);
  console.log('applied', f);
}
await pool.end();
