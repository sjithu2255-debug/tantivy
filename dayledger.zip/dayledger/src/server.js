import express from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { q, tx, workDate } from './db.js';
import { hashPassword, verifyPassword, issueSession, clearSession, requireAuth, requireAdmin } from './auth.js';
import { monthlyCsv } from './report.js';
import 'dotenv/config';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com'],
    scriptSrc: ["'self'"],
    imgSrc: ["'self'", 'data:']
  }
}}));
app.use(express.json({ limit: '64kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));

const OPEN_STATUSES = ['not_started', 'in_progress', 'blocked'];

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */

/** Today's running session, if the clock is still going. */
async function openDayFor(userId) {
  const { rows } = await q(
    `SELECT id, work_date, clock_in_at FROM work_days
     WHERE user_id = $1 AND clock_out_at IS NULL
     ORDER BY work_date ASC LIMIT 1`,
    [userId]
  );
  return rows[0] || null;
}

/**
 * An earlier day that still owes a timesheet. Two ways to get here: the clock
 * is still running from a closed tab, or the nightly sweep stamped a
 * provisional clock-out but nobody ever logged their hours. Both block today.
 */
async function pendingTimesheetFor(userId) {
  const { rows } = await q(
    `SELECT w.id, w.work_date, w.clock_in_at, w.clock_out_at, w.close_reason
     FROM work_days w
     WHERE w.user_id = $1
       AND w.work_date < $2::date
       AND NOT EXISTS (SELECT 1 FROM time_entries te WHERE te.work_day_id = w.id)
     ORDER BY w.work_date ASC LIMIT 1`,
    [userId, workDate()]
  );
  return rows[0] || null;
}

async function openTasksFor(userId) {
  const { rows } = await q(
    `SELECT id, title, note, due_at, status FROM tasks
     WHERE assignee_id = $1 AND archived = FALSE AND status = ANY($2)
     ORDER BY due_at ASC`,
    [userId, OPEN_STATUSES]
  );
  return rows;
}

const shape = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

/* ------------------------------------------------------------------ *
 * Auth + the day session
 * ------------------------------------------------------------------ */

const loginLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true });

app.post('/api/login', loginLimit, async (req, res) => {
  const body = z.object({
    email: z.string().email(),
    password: z.string().min(1)
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Enter an email and password' });

  const { rows } = await q('SELECT * FROM users WHERE lower(email) = lower($1) AND active = TRUE', [body.data.email]);
  const user = rows[0];
  // Constant-ish time: always run a verify so a missing user is not faster.
  const ok = user ? await verifyPassword(user.password_hash, body.data.password).catch(() => false) : false;
  if (!ok) return res.status(401).json({ error: 'Email or password is incorrect' });

  issueSession(res, user);

  // An unfinished earlier day blocks today's clock-in.
  const pending = await pendingTimesheetFor(user.id);
  if (pending) {
    return res.json({
      user: shape(user),
      state: 'catchup_required',
      strandedDay: pending,
      openTasks: await openTasksFor(user.id)
    });
  }

  // First sign-in of the day is the clock-in.
  const today = workDate();
  let day = await openDayFor(user.id);
  if (!day) {
    const ins = await q(
      `INSERT INTO work_days (user_id, work_date, clock_in_at) VALUES ($1, $2, now())
       ON CONFLICT (user_id, work_date) DO UPDATE SET work_date = EXCLUDED.work_date
       RETURNING id, work_date, clock_in_at`,
      [user.id, today]
    );
    day = ins.rows[0];
  }
  res.json({ user: shape(user), state: 'clocked_in', day, mustReset: user.must_reset });
});

app.get('/api/me', requireAuth, async (req, res) => {
  const open = await openDayFor(req.user.id);
  res.json({ user: shape(req.user), day: open });
});

/** Close a day. This is the gate — the API refuses to close without a full timesheet. */
app.post('/api/day/close', requireAuth, async (req, res) => {
  const body = z.object({
    dayId: z.number().int(),
    entries: z.array(z.object({
      taskId: z.number().int(),
      hours: z.number().min(0).max(16),
      status: z.enum(['in_progress', 'blocked', 'completed', 'rolled'])
    }))
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Timesheet is incomplete or malformed' });

  const { dayId, entries } = body.data;

  try {
    const result = await tx(async (c) => {
      const { rows: dayRows } = await c.query(
        'SELECT * FROM work_days WHERE id = $1 AND user_id = $2 FOR UPDATE',
        [dayId, req.user.id]
      );
      const day = dayRows[0];
      if (!day) return { code: 404, payload: { error: 'That day is not yours' } };
      // An auto-closed day still accepts its timesheet; a properly closed one does not.
      if (day.clock_out_at && day.close_reason !== 'idle_timeout') {
        return { code: 409, payload: { error: 'That day is already closed' } };
      }

      // Server-side completeness check. The disabled button in the UI is a courtesy;
      // this is the rule.
      const open = await openTasksFor(req.user.id);
      const covered = new Set(entries.map(e => e.taskId));
      const missing = open.filter(t => !covered.has(t.id));
      if (missing.length) {
        return { code: 422, payload: {
          error: 'Every open task needs hours and a status',
          missing: missing.map(t => ({ id: t.id, title: t.title }))
        }};
      }

      for (const e of entries) {
        const { rows: tRows } = await c.query(
          'SELECT status FROM tasks WHERE id = $1 AND assignee_id = $2 FOR UPDATE',
          [e.taskId, req.user.id]
        );
        if (!tRows[0]) continue;
        const from = tRows[0].status;
        // 'rolled' means "carry on tomorrow" — the task stays open.
        const to = e.status === 'rolled' ? 'in_progress' : e.status;

        await c.query(
          `INSERT INTO time_entries (work_day_id, task_id, hours, status_set)
           VALUES ($1, $2, $3, $4)
           ON CONFLICT (work_day_id, task_id) DO UPDATE SET hours = EXCLUDED.hours, status_set = EXCLUDED.status_set`,
          [dayId, e.taskId, e.hours, e.status]
        );
        await c.query(
          `UPDATE tasks SET status = $1, completed_at = CASE WHEN $1 = 'completed' THEN now() ELSE NULL END
           WHERE id = $2`,
          [to, e.taskId]
        );
        if (from !== to) {
          await c.query(
            'INSERT INTO task_events (task_id, actor_id, from_status, to_status) VALUES ($1,$2,$3,$4)',
            [e.taskId, req.user.id, from, to]
          );
        }
      }

      const isCatchup = day.work_date.toISOString().slice(0, 10) < workDate();
      await c.query(
        `UPDATE work_days
         SET clock_out_at = COALESCE(clock_out_at, now()),
             close_reason = $1, closed_by = $2
         WHERE id = $3`,
        [isCatchup ? 'catchup' : 'user', req.user.id, dayId]
      );
      return { code: 200, payload: { ok: true, closedDayId: dayId } };
    });
    res.status(result.code).json(result.payload);
  } catch (err) {
    console.error('day/close failed', err);
    res.status(500).json({ error: 'Could not save the timesheet. Nothing was changed.' });
  }
});

/** After a catch-up close, start today. */
app.post('/api/day/open', requireAuth, async (req, res) => {
  const pending = await pendingTimesheetFor(req.user.id);
  if (pending) {
    return res.status(409).json({ error: 'Close the earlier day first', strandedDay: pending });
  }
  const today = workDate();
  const { rows } = await q(
    `INSERT INTO work_days (user_id, work_date, clock_in_at) VALUES ($1, $2, now())
     ON CONFLICT (user_id, work_date) DO UPDATE SET work_date = EXCLUDED.work_date
     RETURNING id, work_date, clock_in_at`,
    [req.user.id, today]
  );
  res.json({ day: rows[0] });
});

/** Sign out. Refuses while a day is open — the browser cannot talk its way past this. */
app.post('/api/logout', requireAuth, async (req, res) => {
  const open = await openDayFor(req.user.id);
  if (open) {
    return res.status(409).json({
      error: 'Close your day before signing out',
      day: open,
      openTasks: await openTasksFor(req.user.id)
    });
  }
  clearSession(res);
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ *
 * Tasks
 * ------------------------------------------------------------------ */

app.get('/api/tasks', requireAuth, async (req, res) => {
  const mine = req.user.role !== 'admin' || req.query.scope === 'mine';
  const { rows } = await q(
    `SELECT t.id, t.title, t.note, t.due_at, t.status, t.assignee_id, u.name AS assignee_name
     FROM tasks t JOIN users u ON u.id = t.assignee_id
     WHERE t.archived = FALSE AND ($1::int IS NULL OR t.assignee_id = $1)
     ORDER BY t.status = 'completed', t.due_at ASC`,
    [mine ? req.user.id : null]
  );
  res.json({ tasks: rows });
});

app.post('/api/tasks', requireAuth, requireAdmin, async (req, res) => {
  const body = z.object({
    title: z.string().min(2).max(200),
    note: z.string().max(1000).optional().default(''),
    assigneeId: z.number().int(),
    dueAt: z.string().datetime()
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Check the title, assignee and due date' });

  const { rows } = await q(
    `INSERT INTO tasks (title, note, assignee_id, created_by, due_at)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [body.data.title, body.data.note, body.data.assigneeId, req.user.id, body.data.dueAt]
  );
  res.status(201).json({ task: rows[0] });
});

app.patch('/api/tasks/:id', requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const body = z.object({
    status: z.enum(['not_started', 'in_progress', 'blocked', 'completed']).optional(),
    dueAt: z.string().datetime().optional(),
    note: z.string().max(1000).optional()
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Nothing valid to update' });

  const { rows: cur } = await q('SELECT * FROM tasks WHERE id = $1', [id]);
  if (!cur[0]) return res.status(404).json({ error: 'Task not found' });
  if (cur[0].assignee_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'That task belongs to someone else' });
  }
  // Only admins move due dates.
  if (body.data.dueAt && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Ask an admin to change the due date' });
  }

  const d = body.data;
  const { rows } = await q(
    `UPDATE tasks SET
       status = COALESCE($1, status),
       due_at = COALESCE($2, due_at),
       note = COALESCE($3, note),
       completed_at = CASE WHEN $1 = 'completed' THEN now()
                           WHEN $1 IS NOT NULL THEN NULL ELSE completed_at END
     WHERE id = $4 RETURNING *`,
    [d.status ?? null, d.dueAt ?? null, d.note ?? null, id]
  );
  if (d.status && d.status !== cur[0].status) {
    await q('INSERT INTO task_events (task_id, actor_id, from_status, to_status) VALUES ($1,$2,$3,$4)',
      [id, req.user.id, cur[0].status, d.status]);
  }
  res.json({ task: rows[0] });
});

/* ------------------------------------------------------------------ *
 * Admin: people, override, reports
 * ------------------------------------------------------------------ */

app.get('/api/users', requireAuth, requireAdmin, async (_req, res) => {
  const { rows } = await q('SELECT id, name, email, role, active FROM users ORDER BY name');
  res.json({ users: rows });
});

app.post('/api/users', requireAuth, requireAdmin, async (req, res) => {
  const body = z.object({
    name: z.string().min(2),
    email: z.string().email(),
    role: z.enum(['employee', 'admin']).default('employee'),
    tempPassword: z.string().min(10)
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Name, email and a 10+ character temporary password' });

  const hash = await hashPassword(body.data.tempPassword);
  try {
    const { rows } = await q(
      `INSERT INTO users (name, email, role, password_hash) VALUES ($1,$2,$3,$4)
       RETURNING id, name, email, role`,
      [body.data.name, body.data.email.toLowerCase(), body.data.role, hash]
    );
    res.status(201).json({ user: rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'That email already has an account' });
    throw e;
  }
});

/** Unblock someone whose Friday went unclosed. */
app.post('/api/admin/close-day', requireAuth, requireAdmin, async (req, res) => {
  const body = z.object({
    dayId: z.number().int(),
    clockOutAt: z.string().datetime(),
    note: z.string().min(3).max(500)
  }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'A time and a reason are required' });

  const { rowCount } = await q(
    `UPDATE work_days SET clock_out_at = $1, close_reason = 'admin', closed_by = $2, admin_note = $3
     WHERE id = $4 AND clock_out_at IS NULL`,
    [body.data.clockOutAt, req.user.id, body.data.note, body.data.dayId]
  );
  if (!rowCount) return res.status(404).json({ error: 'No open day with that id' });
  res.json({ ok: true });
});

app.get('/api/reports/monthly.csv', requireAuth, requireAdmin, async (req, res) => {
  const month = z.string().regex(/^\d{4}-\d{2}$/).safeParse(req.query.month);
  if (!month.success) return res.status(400).json({ error: 'Pass month=YYYY-MM' });
  const csv = await monthlyCsv(month.data);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="dayledger-${month.data}.csv"`);
  res.send(csv);
});

app.get('/healthz', (_req, res) => res.json({ ok: true }));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Something broke on our side' });
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Day Ledger listening on :${port}`));
