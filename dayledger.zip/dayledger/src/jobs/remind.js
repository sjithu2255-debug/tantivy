/**
 * Due-date reminder. Run every 3 hours during work hours:
 *   0 9,12,15,18 * * 1-5   (IST)
 * Sends only to people with something due inside the window, and never twice
 * within REMIND_EVERY_HOURS — so a retrying scheduler can't spam anyone.
 */
import nodemailer from 'nodemailer';
import { DateTime } from 'luxon';
import { q, pool, ZONE } from '../db.js';
import 'dotenv/config';

const EVERY_HOURS = Number(process.env.REMIND_EVERY_HOURS || 3);
const HORIZON_HOURS = Number(process.env.REMIND_HORIZON_HOURS || 72);

const mailer = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    })
  : null;

function urgency(dueAt) {
  const h = DateTime.fromJSDate(dueAt).diff(DateTime.now(), 'hours').hours;
  if (h < 0) return 'overdue';
  if (h < 24) return 'due today';
  return 'due soon';
}

function relative(dueAt) {
  const d = DateTime.fromJSDate(dueAt).setZone(ZONE);
  return d.toRelative({ base: DateTime.now() });
}

async function main() {
  const { rows } = await q(
    `SELECT u.id, u.name, u.email, u.slack_user_id,
            t.id AS task_id, t.title, t.due_at
     FROM tasks t
     JOIN users u ON u.id = t.assignee_id
     WHERE t.archived = FALSE
       AND t.status <> 'completed'
       AND t.due_at < now() + ($1 || ' hours')::interval
       AND u.active = TRUE
       AND NOT EXISTS (
         SELECT 1 FROM reminder_log r
         WHERE r.user_id = u.id AND r.sent_at > now() - ($2 || ' hours')::interval
       )
     ORDER BY u.id, t.due_at ASC`,
    [HORIZON_HOURS, EVERY_HOURS]
  );

  const byUser = new Map();
  for (const r of rows) {
    if (!byUser.has(r.id)) byUser.set(r.id, { user: r, tasks: [] });
    byUser.get(r.id).tasks.push(r);
  }

  for (const { user, tasks } of byUser.values()) {
    const worst = tasks.some(t => t.due_at < new Date()) ? 'overdue' : urgency(tasks[0].due_at);
    const lines = tasks.map(t => `• ${t.title} — ${urgency(t.due_at)}, ${relative(t.due_at)}`);
    const subject = worst === 'overdue'
      ? `${tasks.filter(t => t.due_at < new Date()).length} task(s) overdue`
      : `${tasks.length} task(s) due soon`;
    const text = `${user.name},\n\n${lines.join('\n')}\n\nUpdate them: ${process.env.APP_URL}\n`;

    const channels = [];
    if (mailer) {
      await mailer.sendMail({ from: process.env.MAIL_FROM, to: user.email, subject, text });
      channels.push('email');
    }
    if (process.env.SLACK_WEBHOOK_URL) {
      await fetch(process.env.SLACK_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: `${user.slack_user_id ? `<@${user.slack_user_id}>` : user.name} — ${subject}\n${lines.join('\n')}`
        })
      });
      channels.push('slack');
    }
    if (!channels.length) { console.log(`[dry run] ${user.email}: ${subject}`); continue; }

    await q('INSERT INTO reminder_log (user_id, channel, task_ids) VALUES ($1,$2,$3)',
      [user.id, channels.join('+'), tasks.map(t => t.task_id)]);
    console.log(`reminded ${user.email} via ${channels.join('+')} (${tasks.length} tasks)`);
  }

  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
