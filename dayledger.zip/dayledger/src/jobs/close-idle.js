/**
 * Nightly sweep. Run once after hours:  30 22 * * *  (IST)
 *
 * Any day still open from an earlier date gets a provisional clock-out at
 * IDLE_CLOSE_AT local time, marked 'idle_timeout'. The timesheet is still
 * missing, so the person is still forced through catch-up at next sign-in —
 * this only stops the clock running for 60 hours over a weekend.
 */
import { DateTime } from 'luxon';
import { q, pool, ZONE, workDate } from '../db.js';
import 'dotenv/config';

const CLOSE_AT = process.env.IDLE_CLOSE_AT || '19:00';

async function main() {
  const { rows } = await q(
    `SELECT id, user_id, work_date, clock_in_at FROM work_days
     WHERE clock_out_at IS NULL AND work_date < $1::date`,
    [workDate()]
  );

  for (const day of rows) {
    const [h, m] = CLOSE_AT.split(':').map(Number);
    const cutoff = DateTime.fromISO(day.work_date.toISOString().slice(0, 10), { zone: ZONE })
      .set({ hour: h, minute: m });
    // Never stamp a clock-out before the clock-in.
    const out = cutoff.toJSDate() > day.clock_in_at ? cutoff.toJSDate() : day.clock_in_at;

    await q(
      `UPDATE work_days SET clock_out_at = $1, close_reason = 'idle_timeout' WHERE id = $2`,
      [out, day.id]
    );
    console.log(`auto-closed day ${day.id} (user ${day.user_id}, ${day.work_date.toISOString().slice(0,10)})`);
  }

  console.log(`${rows.length} day(s) auto-closed`);
  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
