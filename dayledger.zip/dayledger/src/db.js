import pg from 'pg';
import { DateTime } from 'luxon';
import 'dotenv/config';

export const ZONE = process.env.TZ_NAME || 'Asia/Kolkata';

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'require' ? { rejectUnauthorized: false } : undefined,
  max: 5
});

export const q = (text, params) => pool.query(text, params);

/** Run fn inside a transaction; rolls back on throw. */
export async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/** The local calendar day, so a 9pm session belongs to the right date. */
export const workDate = (d = new Date()) =>
  DateTime.fromJSDate(d).setZone(ZONE).toISODate();

export const localNow = () => DateTime.now().setZone(ZONE);
