import { pool, q } from './db.js';
import { hashPassword } from './auth.js';
import 'dotenv/config';

const { ADMIN_EMAIL, ADMIN_NAME, ADMIN_PASSWORD } = process.env;
if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
  console.error('Set ADMIN_EMAIL, ADMIN_NAME and ADMIN_PASSWORD, then run again.');
  process.exit(1);
}
if (ADMIN_PASSWORD.length < 12) {
  console.error('Use a password of at least 12 characters.');
  process.exit(1);
}

const hash = await hashPassword(ADMIN_PASSWORD);
await q(
  `INSERT INTO users (name, email, role, password_hash, must_reset)
   VALUES ($1, lower($2), 'admin', $3, FALSE)
   ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = 'admin'`,
  [ADMIN_NAME || 'Admin', ADMIN_EMAIL, hash]
);
console.log(`admin ready: ${ADMIN_EMAIL}`);
await pool.end();
