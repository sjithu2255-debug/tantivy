import argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { q } from './db.js';
import 'dotenv/config';

const SECRET = process.env.SESSION_SECRET;
if (!SECRET || SECRET.length < 32) {
  throw new Error('SESSION_SECRET must be set to a random string of 32+ characters');
}

const COOKIE = 'dl_session';
const MAX_AGE_MS = 12 * 60 * 60 * 1000; // a session cannot outlive a working day

export const hashPassword = (plain) =>
  argon2.hash(plain, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });

export const verifyPassword = (hash, plain) => argon2.verify(hash, plain);

export function issueSession(res, user) {
  const token = jwt.sign(
    { uid: user.id, role: user.role },
    SECRET,
    { expiresIn: MAX_AGE_MS / 1000 }
  );
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: MAX_AGE_MS,
    path: '/'
  });
}

export const clearSession = (res) => res.clearCookie(COOKIE, { path: '/' });

/** Attaches req.user, or 401s. */
export async function requireAuth(req, res, next) {
  const raw = req.cookies?.[COOKIE];
  if (!raw) return res.status(401).json({ error: 'Not signed in' });
  try {
    const { uid } = jwt.verify(raw, SECRET);
    const { rows } = await q(
      'SELECT id, email, name, role, must_reset FROM users WHERE id = $1 AND active = TRUE',
      [uid]
    );
    if (!rows[0]) return res.status(401).json({ error: 'Account is no longer active' });
    req.user = rows[0];
    next();
  } catch {
    clearSession(res);
    res.status(401).json({ error: 'Session expired. Sign in again.' });
  }
}

export function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admins only' });
  next();
}
