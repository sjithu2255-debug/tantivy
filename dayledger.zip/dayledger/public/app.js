/* Day Ledger client. The server owns every rule in here — this layer only
   makes the rules pleasant to follow. */
(function () {
  const HOUR = 3600000, DAY = 86400000;
  const $ = (id) => document.getElementById(id);

  let me = null, day = null, tasks = [], scope = 'mine', mode = 'logout', timer = null;

  const api = async (path, opts = {}) => {
    const res = await fetch(path, {
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      ...opts,
      body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status, data });
    return data;
  };

  const fmtTime = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const STATUS_LABEL = {
    not_started: 'Not started', in_progress: 'In progress',
    blocked: 'Blocked', completed: 'Completed', rolled: 'Rolled over'
  };

  function urgency(t) {
    if (t.status === 'completed') return { key: 'done', label: 'Done', rank: 4 };
    const h = (new Date(t.due_at) - Date.now()) / HOUR;
    if (h < 0) return { key: 'urgent', label: 'Overdue', rank: 0 };
    if (h < 24) return { key: 'urgent', label: 'Due today', rank: 1 };
    if (h < 72) return { key: 'soon', label: 'Due soon', rank: 2 };
    return { key: 'calm', label: 'On track', rank: 3 };
  }

  function dueText(t) {
    const d = new Date(t.due_at) - Date.now(), a = Math.abs(d);
    const n = a < DAY ? Math.max(1, Math.round(a / HOUR)) + 'h' : Math.round(a / DAY) + 'd';
    return d < 0 ? n + ' overdue' : 'in ' + n;
  }

  /* ---------------- sign in ---------------- */

  async function signIn() {
    const btn = $('loginBtn');
    btn.disabled = true;
    $('loginErr').textContent = '';
    try {
      const out = await api('/api/login', {
        method: 'POST',
        body: { email: $('email').value.trim(), password: $('password').value }
      });
      me = out.user;
      $('password').value = '';
      if (out.state === 'catchup_required') {
        enterApp();
        openSheet('catchup', out.strandedDay, out.openTasks);
      } else {
        day = out.day;
        enterApp();
        await refresh();
        startAlerts();
      }
    } catch (err) {
      $('loginErr').textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  }

  function enterApp() {
    $('login').style.display = 'none';
    $('app').style.display = 'block';
    $('whoAmI').textContent = '— ' + me.name;
    if (me.role === 'admin') $('adminBar').style.display = 'flex';
    if (day) {
      $('clockLabel').textContent = 'Clocked in ' + fmtTime(day.clock_in_at);
      $('dayMeta').textContent = new Date().toLocaleDateString([], {
        weekday: 'long', day: 'numeric', month: 'long'
      }) + ' · started ' + fmtTime(day.clock_in_at);
    }
  }

  /* ---------------- ledger ---------------- */

  async function refresh() {
    const out = await api('/api/tasks' + (scope === 'all' ? '?scope=all' : ''));
    tasks = out.tasks;
    render();
  }

  function render() {
    const el = $('ledger');
    const sorted = tasks.slice().sort((a, b) =>
      urgency(a).rank - urgency(b).rank || new Date(a.due_at) - new Date(b.due_at));

    if (!sorted.length) {
      el.innerHTML = '<div class="empty">No tasks assigned. Nothing to close out.</div>';
      return;
    }

    el.innerHTML = '<div class="lrow lhead"><div></div><div>Task</div><div>Due</div><div>Status</div></div>';
    for (const t of sorted) {
      const u = urgency(t);
      const row = document.createElement('div');
      row.className = 'lrow' + (u.key === 'urgent' ? ' row-urgent' : '') + (u.key === 'done' ? ' row-done' : '');
      row.innerHTML =
        '<div class="stripe s-' + u.key + '"></div>' +
        '<div class="cell"><div class="title"></div><div class="sub"></div>' +
          (scope === 'all' ? '<div class="assignee"></div>' : '') +
          '<div class="mobile-meta"><span class="pill u-' + u.key + '">' + u.label + '</span>' +
          '<span class="sub num">' + (u.key === 'done' ? '' : dueText(t)) + '</span></div></div>' +
        '<div class="cell due-cell"><div class="due u-' + u.key + ' num">' +
          (u.key === 'done' ? '—' : dueText(t)) + '<small>' +
          new Date(t.due_at).toLocaleDateString([], { day: 'numeric', month: 'short' }) +
          '</small></div></div>' +
        '<div class="cell status-cell"><span class="pill u-' + u.key + '">' +
          (STATUS_LABEL[t.status] || t.status) + '</span></div>';
      // textContent, not innerHTML — task titles are user input.
      row.querySelector('.title').textContent = t.title;
      row.querySelector('.sub').textContent = t.note || '';
      if (scope === 'all') row.querySelector('.assignee').textContent = t.assignee_name;
      el.appendChild(row);
    }
  }

  /* ---------------- in-app reminder (the email job is the real one) ---------------- */

  function startAlerts() {
    clearInterval(timer);
    timer = setInterval(fireAlert, 3 * HOUR);
    setTimeout(fireAlert, 1200);
    setInterval(render, 60000); // keep the colours honest as deadlines approach
  }

  function fireAlert() {
    const live = tasks.filter(t => t.status !== 'completed')
      .sort((a, b) => new Date(a.due_at) - new Date(b.due_at)).slice(0, 3);
    if (!live.length) return;
    const worst = urgency(live[0]);
    const toast = $('toast');
    toast.classList.toggle('hot', worst.key === 'urgent');
    $('toastTitle').textContent = worst.key === 'urgent' ? 'Needs attention now' : 'Coming up';
    const ul = document.createElement('ul');
    for (const t of live) {
      const u = urgency(t);
      const li = document.createElement('li');
      const a = document.createElement('span'); a.textContent = t.title;
      const b = document.createElement('span');
      b.className = 'u-' + u.key + ' num'; b.style.whiteSpace = 'nowrap'; b.textContent = dueText(t);
      li.append(a, b); ul.appendChild(li);
    }
    $('toastBody').replaceChildren(ul);
    $('toastNext').textContent = 'Next reminder in 3 hours.';
    toast.classList.add('on');
  }

  /* ---------------- the gate ---------------- */

  async function openSheet(which, strandedDay, presetTasks) {
    mode = which;
    const target = which === 'catchup' ? strandedDay : day;
    const open = presetTasks || tasks.filter(t => t.status !== 'completed');

    $('sheetTitle').textContent = which === 'catchup' ? 'Finish your last day first' : 'Close out your day';
    $('sheetIntro').textContent = which === 'catchup'
      ? 'Your last session ended without a timesheet. Complete it to clock in for today.'
      : 'Log hours and set a status for each open task. Both are required to sign out.';

    const body = $('sheetBody');
    body.replaceChildren();
    if (which === 'catchup') {
      const warn = document.createElement('div');
      warn.className = 'warnbar';
      const d = new Date(strandedDay.work_date).toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'short' });
      warn.textContent = `Signed in ${d} at ${fmtTime(strandedDay.clock_in_at)}, never signed out. Today starts once this is submitted.`;
      body.appendChild(warn);
    }

    for (const t of open) {
      const u = urgency(t);
      const row = document.createElement('div');
      row.className = 'entry';
      row.innerHTML =
        '<div class="top"><div><div class="title"></div><div class="sub"></div></div>' +
        '<span class="pill u-' + u.key + '" style="white-space:nowrap">' + dueText(t) + '</span></div>' +
        '<div class="fields">' +
          '<label>Status<select data-task="' + t.id + '" data-f="status">' +
            '<option value="">Select…</option>' +
            '<option value="in_progress">Still in progress</option>' +
            '<option value="completed">Completed</option>' +
            '<option value="blocked">Blocked</option>' +
            '<option value="rolled">Rolled to tomorrow</option>' +
          '</select></label>' +
          '<label>Hours today<input data-task="' + t.id + '" data-f="hours" type="number" ' +
            'min="0" max="16" step="0.25" inputmode="decimal" placeholder="0.00"></label>' +
        '</div>';
      row.querySelector('.title').textContent = t.title;
      row.querySelector('.sub').textContent = t.note || '';
      body.appendChild(row);
    }

    if (!open.length) {
      const w = document.createElement('div');
      w.className = 'warnbar';
      w.textContent = 'No open tasks. You are clear to sign out.';
      body.appendChild(w);
    }

    body.querySelectorAll('select,input').forEach(f => f.addEventListener('input', validate));
    $('cancelBtn').style.display = which === 'catchup' ? 'none' : '';
    $('confirmBtn').textContent = which === 'catchup' ? 'Submit and clock in' : 'Sign out';
    $('confirmBtn').dataset.dayId = target.id;
    $('veil').classList.add('on');
    validate();
  }

  function collect() {
    const by = {};
    $('sheetBody').querySelectorAll('select,input').forEach(f => {
      by[f.dataset.task] = by[f.dataset.task] || {};
      by[f.dataset.task][f.dataset.f] = f.value;
    });
    return by;
  }

  function validate() {
    const fields = [...$('sheetBody').querySelectorAll('select,input')];
    let ok = true, total = 0, missing = 0;
    for (const f of fields) {
      const filled = f.value !== '' && !(f.dataset.f === 'hours' && Number(f.value) < 0);
      if (!filled) { ok = false; missing++; }
      f.classList.toggle('needed', !filled && f.dataset.touched === '1');
      if (f.dataset.f === 'hours' && filled) total += Number(f.value);
    }
    $('confirmBtn').disabled = !ok;
    $('totalLabel').innerHTML = ok
      ? 'Total logged: <b class="num">' + total.toFixed(2) + ' h</b>'
      : missing + (missing === 1 ? ' field' : ' fields') + ' still needed';
  }

  async function submitSheet() {
    const btn = $('confirmBtn');
    btn.disabled = true;
    const entries = Object.entries(collect()).map(([taskId, v]) => ({
      taskId: Number(taskId), hours: Number(v.hours), status: v.status
    }));
    try {
      await api('/api/day/close', { method: 'POST', body: { dayId: Number(btn.dataset.dayId), entries } });
      if (mode === 'catchup') {
        const out = await api('/api/day/open', { method: 'POST' });
        day = out.day;
        $('veil').classList.remove('on');
        enterApp();
        await refresh();
        startAlerts();
        return;
      }
      await api('/api/logout', { method: 'POST' });
      clearInterval(timer);
      location.reload();
    } catch (err) {
      btn.disabled = false;
      alert(err.message);
    }
  }

  /* ---------------- admin ---------------- */

  async function assignTask() {
    const { users } = await api('/api/users');
    const title = prompt('Task title');
    if (!title) return;
    const who = prompt('Assign to (email):\n' + users.map(u => u.email).join('\n'));
    const user = users.find(u => u.email.toLowerCase() === (who || '').trim().toLowerCase());
    if (!user) return alert('No active account with that email.');
    const dueStr = prompt('Due date and time (YYYY-MM-DD HH:MM)');
    const due = new Date((dueStr || '').replace(' ', 'T'));
    if (isNaN(due)) return alert('Could not read that date.');
    try {
      await api('/api/tasks', {
        method: 'POST',
        body: { title, note: '', assigneeId: user.id, dueAt: due.toISOString() }
      });
      await refresh();
    } catch (err) { alert(err.message); }
  }

  /* ---------------- wiring ---------------- */

  $('loginBtn').onclick = signIn;
  $('password').addEventListener('keydown', e => { if (e.key === 'Enter') signIn(); });
  $('email').addEventListener('keydown', e => { if (e.key === 'Enter') $('password').focus(); });

  $('logoutBtn').onclick = async () => { await refresh(); openSheet('logout'); };

  $('cancelBtn').onclick = () => {
    $('sheetBody').querySelectorAll('select,input').forEach(f => f.dataset.touched = '1');
    $('veil').classList.remove('on');
  };
  $('confirmBtn').onclick = submitSheet;
  $('toastX').onclick = () => $('toast').classList.remove('on');

  $('newTaskBtn').onclick = assignTask;
  $('scopeBtn').onclick = async (e) => {
    scope = scope === 'mine' ? 'all' : 'mine';
    e.target.textContent = scope === 'all' ? 'Show only my tasks' : "Show everyone's tasks";
    $('viewTitle').textContent = scope === 'all' ? 'All tasks' : 'Your tasks';
    await refresh();
  };
  $('reportBtn').onclick = () => {
    const m = new Date().toISOString().slice(0, 7);
    location.href = '/api/reports/monthly.csv?month=' + m;
  };

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && $('veil').classList.contains('on') && mode !== 'catchup') $('cancelBtn').click();
  });

  // Resume an existing session on reload.
  api('/api/me').then(async out => {
    me = out.user; day = out.day;
    if (!day) return;
    enterApp(); await refresh(); startAlerts();
  }).catch(() => {});
})();
